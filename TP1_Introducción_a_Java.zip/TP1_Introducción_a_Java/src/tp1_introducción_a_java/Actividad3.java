package tp1_introducci�n_a_java;
public class Actividad3 {
    public static void main(String[] args) {
        String nombre = "Lorenzo";
        int edad = 25;
        double altura = 1.79;
        boolean estudiante = true;
        System.out.println("Mi nombre es " + nombre + ", tengo " + edad + " a�os y mido " + altura + ". Soy estudiante en TUPAD UTN: " + estudiante);
    }
}
