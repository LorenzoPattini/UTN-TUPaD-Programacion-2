package tp1_introducci�n_a_java;
public class HolaMundo {
    public static void main(String[] args) {
        System.out.println("�Hola, Java!");
    }
}