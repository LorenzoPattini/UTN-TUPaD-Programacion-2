package tp1_introducci�n_a_java;
public class Actividad6 {
    public static void main(String[] args) {
        System.out.println("Nombre: Juan Perez\nEdad: 30 a�os\nDireccion: \"Calle Falsa 123\"");
    }
}
